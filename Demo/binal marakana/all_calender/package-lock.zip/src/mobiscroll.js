import React, { Component } from 'react';

/* import Mobiscroll JS and CSS */
import  mobiscroll from "@mobiscroll/react";
import "@mobiscroll/react/dist/css/mobiscroll.min.css"; /* change the css location if you are using the cli config with --no-npm */

class App extends Component {
  render() {
    return (
     <div></div>
    );
  }
}
export default App;