var product_data = [
    {
        "productId": "1",
        "productName": "ProductA",
        "productPrice": "1562",
        "ProductDateCreated": "2015-07-24T12:58:17.430Z",
        "TotalProduct": 294
    },
    {
        "productId": "2",
        "productName": "ProductB",
        "productPrice": "8545",
        "TotalProduct": 294,
       
    },
    {
        "productId": "3",
        "productName": "ProductC",
        "productPrice": "8654",
        "TotalProduct": 78,
       
    },
    {
        "productId": "4",
        "productName": "ProductD",
        "productPrice": "87456",
        "TotalProduct": 878,
    }
];