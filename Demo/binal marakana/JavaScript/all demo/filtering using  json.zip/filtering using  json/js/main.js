var product_data =
{   
    "products": [
     {
        "proname": "Fruits",
        "item": [{ 
            "productId": "1",
            "productName": "ProductA",
            "productPrice": "1562",
            "photo":"img/strawberry.jpeg"
        }, {
            "productId": "2",
            "productName": "ProductB",
            "productPrice": "8545",
            "photo":"img/orange.png" 
        }]
    },
    {
        "proname": "Vegetables",
        
        "item": [{ 
            "productId": "3",
            "productName": "ProductC",
            "productPrice": "8654",
            "photo":"img/carrot.png"
        }]
    },
    {
        "proname": "food",
        
        "item": [{ 
            "productId": "4",
            "productName": "ProductD",
            "productPrice": "87456",
            "photo":"img/food1.png"
        }]
    }]
};

function proTemplate()
{
    // return`
    // <div class = "product">
    //     <img class = "pro_photo" src="${pro.photo}">
    //     <h2 class="pro_name">${pro.proname}</h2>
    //     <span class="price">Price:${pro.productPrice} </span>
    // </div>
    // `
debugger
    for (var i = 0, il = product_data.products.length; i < il; i++) {
        var product =  product_data.products[i];

        for (var j = 0, jl = product.item.length; j < jl; j++) {
            debugger
            return `
            <div class ="product">
                <div class = "item">${product.proname}</div>
                <img class = "pro_photo" src="${product.item[j].photo}">
                <h2 class="pro_name">${product.item[j].productName}</h2>
                <span class="price">Price:${product.item[j].productPrice} </span>
            </div>
            `
        }
        
    }
}

document.getElementById("app").innerHTML = `
${product_data.products.map(proTemplate).join('')}
`

// function filterobjects(c){
//     var x, i;
//     x = document.getElementsByClassName("product");
//     if(c == "all") c = "";
//     for (let i = 0; i < x.length; i++) {
//        removeclass(x[i],"show");
//        if(x[i].className.indexOf(c) > -1) addClass(x[i],"show");
        
//     }
// }