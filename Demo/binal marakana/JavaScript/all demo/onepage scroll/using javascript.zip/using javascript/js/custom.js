// document.querySelectorAll('a').forEach(anchor => {
//     anchor.addEventListener('click', function (e) {
//         e.preventDefault();
        
//         document.querySelector(this.getAttribute('href')).scrollIntoView({
//             behavior: 'smooth'
//         });
//     });
// });



var links = document.querySelectorAll("a");
// links.forEach(link => {
//     link.addEventListener("click", clickHandler);
   
// }); 

for (var link of links) {
    link.addEventListener("click", clickHandler);
  
}
  
  function clickHandler(e) {
    e.preventDefault();
    var href = this.getAttribute("href");
    // console.log(href);
    var offsetTop = document.querySelector(href).offsetTop;
    // console.log(offsetTop);

    scroll({
      top: offsetTop,
      behavior: "smooth"
    });
  }

