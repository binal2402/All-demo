var rIndex,new_name = document.getElementById("table");

function display()
{       
      
    // var new_name = document.getElementById('name').value;
    // document.getElementById("f_name").innerHTML = new_name

        // var new_name = document.getElementById("table");
        var new_row = new_name.insertRow(new_name.length);
        var cell1 = new_row.insertCell(0),
            cell2 = new_row.insertCell(1);

        var fname = document.getElementById("fname").value;

        cell1.innerHTML = fname;
        cell2.innerHTML = ' <button onclick = "editrow()">Edit</button> <button onclick="deleteRow(this)">Delete</button> ';

        selectrow();
            
}
function selectrow()
{
   for (let i = 1; i < new_name.rows.length; i++) {
       new_name.rows[i].onclick = function()
       {
            rIndex = this.rowIndex;
            document.getElementById("fname").value =this.cells[0].innerHTML;
       }
        
    }
}
function editrow()
{
    var fname = document.getElementById("fname").value;
    new_name.rows[rIndex].cells[0].innerHTML=fname;
}
selectrow();

function deleteRow(btn) {
    var row = btn.parentNode.parentNode;
    row.parentNode.removeChild(row);
}
window.onload = function () {
    display();
}

