var old_data;
var userData;
function display()
{
    var fname = document.getElementById("fname").value;
    userData = {
        fristName: fname,
      };
    if(localStorage.getItem('data') == null)
    {
        localStorage.setItem('data','[]');
    }
    old_data = JSON.parse(localStorage.getItem('data'));
    old_data.push(userData);
    
    localStorage.setItem('data',JSON.stringify(old_data));
}
function insertdata()
{
    var show_data = JSON.parse(localStorage.getItem('data'))
    // console.log(show_data);
    var table = document.getElementById('table');
    for(var i =0;  i < show_data.length; i++){
    
        var newRow = table.insertRow(table.length);
        var cell1 = newRow.insertCell(0),
          cell2 = newRow.insertCell(1);
          cell3 = newRow.insertCell(2);
          cell4 = newRow.insertCell(3);
    
        cell1.innerHTML = i+1;
        cell2.innerHTML = show_data[i].fristName;
        cell3.innerHTML = ' <button onclick="editrow()">Edit</button> ';
        cell4.innerHTML = ' <button onclick="deleteRow(this)">Delete</button> ';
     }
}

var  rIndex;
function editrow()
{
    var table = document.getElementById("table");
    for (let i = 1; i < table.rows.length; i++) {
        table.rows[i].onclick = function()
        {
             rIndex = this.rowIndex;
             console.log(rIndex);
             var userData = show_data[rIndex - 1];
             console.log(userData);
            document.getElementById("fname").value = userData.fristName;

            //  document.getElementById("fname").value =this.cells[1].innerHTML;
             
        }
         
     }
    
}


function deleteRow(index) {
    var row = index.parentNode.parentNode;
    var table = document.getElementById("table");


    table.deleteRow(row.rowIndex);
    show_data.splice(row.rowIndex, 1);
    console.log(row.rowIndex);
    localStorage.setItem= JSON.stringify(show_data);

}
