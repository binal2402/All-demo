import React, {useState} from 'react'
import Header from '../layout/Header';
import TopDescription from '../components/TopDescription'
import ThankyouSub from './../components/ThankyouSub';
import { Link } from "react-router-dom";

const MvpThankYou = () => {
    const [mvpdata, setmvpData] = useState([
        {
            "Id":"1",
            "ImgUrl": "/images/thankyou.jpg",
            "Title": "Lorem ipsum dolor sit amet",
            "Link":"Learn More"
        },
        {
            "Id":"2",
            "ImgUrl": "/images/img2.png",
            "Title": "Lorem ipsum dolor sit amet",
            "Link":"Learn More"
        },
        {
            "Id":"3",
            "ImgUrl": "/images/thankyou.jpg",
            "Title": "Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit ametLorem ipsum dolor sit amet",
            "Link":"Learn More"
        },
    ]);
   
    return (
        <div>
            <Header />
            <div>
                <div className="sd_container_492">
                    <div className="sd_content">
                        <TopDescription />
                    </div>
                </div>
                <div className="sd_container_1217 border_top_formborder">
                    <div className="sd_thank_you_main sd_flex">
                    {mvpdata.map((item, index) => {
                        return <ThankyouSub data = {item}  />
                    })}
                        
                    </div>
                </div>
            </div>
        </div>
    )
}

export default MvpThankYou