import React from 'react'
import Header from './../layout/Header';
import TopDescription from './../components/TopDescription';
import TextField from './../components/TextField';
import Checkbox from './../components/Checkbox';


const MvpOneTime = () => {
    return (
        <div>
            <Header />
            <div>
                <div className="sd_container_492">
                    <div className="sd_content">
                        <TopDescription />
                    </div>
                    <div className="cat_tabs">
                        <ul className="cat_tabs_wrap sd_flex sd_textcenter sd_aligncenter sd_justbetween">
                            <li className="sd_p_cursor active">
                                <h3>Indie</h3>
                                <p>$65+</p>
                            </li>
                            <li className="sd_p_cursor ">
                                <h3>Indie</h3>
                                <p>$65+</p>
                            </li>
                            <li className="sd_p_cursor ">
                                <h3>Indie</h3>
                                <p>$65+</p>
                            </li>
                        </ul>
                    </div>
                    <div className="installment_tabs">
                        <ul className="border_bottom_gray installment_tabs_wrap sd_flex sd_textcenter sd_aligncenter sd_justbetween">
                            <li className="sd_p_cursor active">12-Month Installments</li>
                            <li className="sd_p_cursor ">Yearly Payments</li>
                        </ul>
                        <div className="installment_tabs_content">
                            <div className="month_tab installment_tab_common">
                                    <div className="sd_flex price_tags_row">
                                        <div className="sd_flex">
                                            <p className="price_tag sd_textcenter"><strong>$6/</strong>mo</p>
                                            <p className="price_tag sd_textcenter"><strong>$6/</strong>mo</p>
                                            <p className="price_tag sd_textcenter"><strong>$6/</strong>mo</p>
                                        </div>
                                        <div className="amount_row">
                                            <div className="amount_row_field sd_relative">
                                                <input type="text" placeholder="Other Amount" />
                                                <strong className="input_dollar">$</strong>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="total_title">
                                        <h6 className="sd_flex sd_textcenter sd_justcenter sd_aligncenter">Your Annual Total <p className="total_price">$66</p></h6>
                                    </div>
                                    <div className="contact_info">
                                        <h2 className="mb_10 contact_info_title">Contact Information</h2>
                                        <div className="sd_flex sd_flexwrap two_field sd_justbetween">
                                            <div className="field_row">
                                                <TextField type="text" label="First Name" disabled={true} />
                                            </div> 
                                            <div className="field_row">
                                                <TextField type="text" label="Last Name" />
                                            </div>
                                            <div className="field_row">
                                                <TextField type="text" label="Email" />
                                            </div>
                                            <div className="field_row">
                                                <TextField type="text" label="Phone Number" />
                                            </div>
                                        </div>
                                        <div className="benifit_msg sd_textcenter">
                                            <i className="sd_p_cursor">Would you like to waive your benefits and make your donation 100% tax deductible? Consider donating through this portal.</i>
                                        </div>
                                        <div className="field_row">
                                            <Checkbox type="checkbox" id="areyou" label="Are you a Sundance Institute Alumni?" />
                                            <Checkbox type="checkbox" id="gift" label="Gift this Membership" />
                                        </div>
                                    </div>

                            </div>
                            <div className="year_tab installment_tab_common">
                               
                            </div>
                        </div>
                       
                    </div>
                </div>
             
            </div>
        </div>
    )
}

export default MvpOneTime