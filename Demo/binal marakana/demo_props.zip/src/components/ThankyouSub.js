import React from 'react'
import { Link } from "react-router-dom";

function ThankyouSub(props) {
    const {data} = props
    return (
        <div className="sd_thank_you_sub">
            <img src={data.ImgUrl} alt="mvpimg"></img>
            <div className="sd_thankyou_content">
                <h1>{data.Title}</h1>
                <Link className="sd_learn_more">{data.Link} <i class="arrow right"></i></Link>
            </div>
        </div>
    )
}
export default ThankyouSub