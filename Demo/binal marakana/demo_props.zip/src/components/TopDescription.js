import React from 'react'

function TopDescription() {
    return (
        <div className="top_description">
            <span className="content_logo">
                <img src="/images/sundance_logo.svg" alt="logo" />
            </span>
            <h4 className="mb_5 sd_textcenter">Become a Sundance Institute Member Today</h4>
            <p className="sd_textcenter">Join our community and in addition to supporting the next generation of independent storytellers, you’ll also unlock access to special events, exclusive access at the Sundance Film Festival, and so much more. Just fill out the form below to get started!</p>
        </div>
    )
}
export default TopDescription
