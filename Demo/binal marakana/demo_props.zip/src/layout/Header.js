import React from "react";
// import { Link, useHistory } from "react-router-dom";

function Header(props) {
	return (
		<div className="sd_header_section header_slider_section sd_relative">
			<header>
				<div className="sd_container_1217">
					<div className="sd_header_sec_wpr">
						<div className="sd_header_wpr sd_flex">
							<div className="sd_header_logo">
								<a className="sd_desktop_logo" href="/">
									<img src="/images/sundance_header_logo.svg" alt="logo" width="132" />
								</a>
								{/* <a className="sd_mobile_logo sd_hidden" href="/"> 
									<img src="/images/header_mobile-logo.svg" alt="Sundance Film Festival 2021" title="Sundance Film Festival 2021" />
								</a> */}
							</div>
							<div className="header_right">
								<div className="sd_flex sd_aligncenter">
									<span className="sd_search sd_p_cursor"><img src="/images/search_icon.svg" alt="logo" width="25" /></span>
									<p className="sd_p_cursor sd_menu_toggle sd_flex sd_justbetween sd_flex_col">
										<span></span>
										<span></span>
										<span></span>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="header_bottom">
					<div className="sd_large_container">
						<div className="sd_flex sd_aligncenter sd_justcenter">
							<h5 className="mr_10">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh</h5>
							<span className="sd_p_cursor border_btn_black">Lorem Ipsum</span>
						</div>
					</div>
				</div>
        	</header>
		</div>
	)
}

export default Header