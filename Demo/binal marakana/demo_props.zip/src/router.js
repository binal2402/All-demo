import React, { Component } from "react";
import {Switch, Route } from "react-router-dom";
// import NotFound from "./pages/not-found";
import MvpOneTime from "./pages/MvpOneTime";
import MvpThankYou from "./pages/MvpThankYou";

class Routers extends Component {
    constructor(props) {
      super(props);
      this.state = {
        isLoading: true,
      };
    }
    render() {
      return (
        <>
      
          <Switch>
                <Route  exact path="/" component={MvpOneTime} />
                <Route  exact path="/mvp-thankyou" component={MvpThankYou} />

          </Switch>
       
            
        </>
      );
    }
  }
  export default Routers;
