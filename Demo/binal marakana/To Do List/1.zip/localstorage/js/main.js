var addtaskinput = document.getElementById('addtaskinput');
var addtaskbtn = document.getElementById('addtaskbtn');


addtaskbtn.addEventListener("click",function(){
    addtaskinputval = addtaskinput.value;
    // alert(addtaskinputval);
    if (addtaskinputval.trim()!=0) {
        var webtask = localStorage.getItem("localtask");
        if(webtask == null)
        {
            taskobj = [];
        }else{
            taskobj = JSON.parse(webtask);
            // console.log(taskobj);
        }
        taskobj.push(addtaskinputval);
        localStorage.setItem("localtask",JSON.stringify(taskobj));  
    }
    showtask();
})

function showtask(){
    var webtask = localStorage.getItem("localtask");
    if(webtask == null)
    {
        taskobj = [];
    }else{
        taskobj = JSON.parse(webtask);
        // console.log(taskobj);
    }
    var html = '';
    var addtasklist = document.getElementById("addedtaskList");
    taskobj.forEach((item,index) => {
        html +=`<tr>
                <th>${index+1}</th>
                <td>${item}</td>
                <td><button class="btn-delete" onclick="deleteitem(${index})">Delete</button></td>
                <td><button class="btn-edit">edit</button></td>
                </tr>`;
    });
    addtasklist.innerHTML=html;
}

function deleteitem(index){
    var webtask = localStorage.getItem("localtask");
    taskobj = JSON.parse(webtask);
    taskobj.splice(index,1);
    localStorage.setItem("localtask",JSON.stringify(taskobj));

}